/*var alumnos = ["Santos", "Corral", "Ramos"];
console.log(alumno[2]);*/




/*var variable1 = "Hola";
var variable2 = "Mundo";
console.log(variable1 + " " + variable2);

var palabra = "Hugo";
console.log(typeof(palabra));
var numerotexto = "10";
console.log(typeof(numerotexto));
var numero =10;
console.log(typeof(numero));
var decimal = 10.0121;
console.log(typeof(decimal));

var resultado = numero + decimal;
console.log(resultado);

var resultado2 = palabra + numero;
console.log(resultado2);

var resultado3 = palabra + numero;
console.log(resultado3);

var conversion = parseInt(numero);
console.log(conversion);*/

var personas =

[{
    nombre: "Briayan", 
   apellidos: 
   {
      paterno: "De La Hoya",
      materno: "Vazquez"
   },
    Profeciones: 
    {
        titulacion : "Tecnico",
        roles: ["Estudiante ","Desarrollador "]
    }
},
{
    nombre: "Jessica", 
    apellidos: 
    {
       paterno: "Santos",
       materno: "Nava"
    },
     Profeciones: 
     {
         titulacion : "Licenciada",
         roles: ["Estudiante ","Piloto ","Desarrollador "]
     }
    
},
{
    nombre: "Paola", 
    apellidos: 
    {
       paterno: "Corral",
       materno: "Seturino"
    },
     Profeciones: 
     {
         titulacion : "Ingeniera",
         roles: ["Estudiante ", "Recepcion "]
     }
    

}];



/*var nombre = [];
var carrera = [];
var apaterno = [];
var amaterno = [];

for(i = 0; i < 3; i++){
    var nom=prompt("Escribe el nombre");
    nombre[i]=nom;
    
    var nom=prompt("Escribe el apellido paterno");
    apaterno[i]=nom;
    
    var nom=prompt("Escriba el apellido materno");
    amaterno[i]=nom;
    
    var nom=prompt("Escribe la carrera");
    carrera[i]=nom;
    
    var nom =prompt("Ingrese su titulacion");
}*/

var per = prompt("Cuanta gente vas a ingresa?");
for(var j=0;j<per;j++){
var nombreTemp = prompt("Ingrese su nombre");
var paternoTemp = prompt("Ingrese su Apellido Paterno");
var maternoTemp = prompt("Ingrese su Apellido Materno");
var titulacionTemp = prompt("Ingrese su Titulacion");
var nroles = prompt("Cuantos roles vas a ingresar?");
var proles = [];
for (var i=0; i<nroles;i++){
    var xrol= prompt("Cual rol tienes?");
    proles[i]=xrol;
}




var objetoTemp = {

    nombre: nombreTemp,
    apellidos: {
        paterno: paternoTemp,
        materno: maternoTemp
    },
    Profeciones: {
        titulacion: titulacionTemp,
        roles: proles
    }
}

personas.push(objetoTemp);
}

var texto = "";
for(var i = 0; i<personas.length;i++)
{
    var texto= ""; texto += personas[i].nombre + " " + personas[i].apellidos.paterno + " " + personas[i].apellidos.materno; texto += " es " + personas[i].Profeciones.titulacion; texto += " y se dedica a "; 
    for(var j = 0; j<personas[i].Profeciones.roles.length;j++) {
       
        texto+=personas[i].Profeciones.roles[j];
        if(j == (personas[i].Profeciones.roles.length-1))
        {
            texto+=".";
        }
        else if(j == (personas[i].Profeciones.roles.length-2)){
            texto+=" y ";
        }
            else{
                texto+=", ";
            }
        
    }
    console.log(texto);

}



